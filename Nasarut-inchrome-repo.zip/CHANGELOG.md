# ประวัติการเปลี่ยนแปลง (Changelog)

โครงการ **Nasarut-inchrome** — SharePoint Framework (SPFx) Web Part สำหรับสร้างลิงก์ที่สามารถเลือกเปิดใน Google Chrome ผ่าน Windows custom protocol `nasarut-inchrome-chrome:`

> เอกสารนี้สรุปจากประวัติ GitHub Commit และโค้ดของโครงการ ไม่ใช่บันทึกการทดสอบหรือการติดตั้งจริงบน SharePoint

## 1.2.1.0 — 21 ตุลาคม 2026 (เวอร์ชันปัจจุบัน)

**ตัวแก้ไขแบบเดียวกับ Text web part ของ SharePoint**

- แถบเครื่องมือเหลือ 4 ปุ่ม (รูปแบบ, ขนาด, ลิงก์, ⋯) ลอยเหนือกรอบต่อจากแถบของ SharePoint ไม่บังข้อความ แสดงเฉพาะตอนคลิกหรือชี้ที่ web part
- เมนู ⋯ เปิดไปทางขวาเหมือน Text มีเมนูย่อยด้านข้าง และแสดงคีย์ลัด
- รูปแบบข้อความ: หัวเรื่อง 1–4, ปกติ, ไม่มีระยะห่าง, คำพูด, ความกว้างคงที่ ช่องขนาดแสดงขนาดจริงของข้อความ
- ตัวคัดลอกรูปแบบ (Ctrl+Alt+C / Ctrl+Alt+V)
- สีตัวอักษร: สีของธีมไซต์, สีมาตรฐาน, สีที่กำหนดเอง (Hex/RGB) และสีไฮไลต์ 15 สี
- ภาษาของข้อความ (การช่วยการเข้าถึง)
- รูปแบบคำพูด: ธรรมดา, เน้น, มีกรอบ, เส้นขอบด้านข้าง, ไอคอนคำพูด
- รายการสัญลักษณ์ (จุด, วงกลม, สี่เหลี่ยม) และรายการลำดับเลข (1, A, a, I, i) พร้อมเริ่มใหม่ / ต่อจากรายการก่อน / เริ่มที่เลข
- ระยะห่างบรรทัด 1.0–2.4, เพิ่มระยะก่อน/หลังย่อหน้า, เยื้องย่อหน้าธรรมดาได้
- แทรกรูปภาพจากที่อยู่รูป และแทรกตารางแบบเลือกขนาดจากตาราง
- หน้าต่าง **แทรกลิงก์** แบบเดียวกับ Text: ที่อยู่, ข้อความที่จะแสดง, ค้นหาหน้าในไซต์, รายการหน้าล่าสุด (คลิกเลือกได้) และสวิตช์ **เปิดด้วย Chrome** กับ **เปิดลิงก์ในแท็บใหม่** ใช้พร้อมกันได้
- ลิงก์ที่ตั้งสีเองแสดงสีนั้นทั้งตัวอักษรและเส้นใต้ และสี/ขนาดที่ติดมากับลิงก์ตอนคัดลอกจาก Text เดิมไม่หาย
- คัดลอกข้อความจาก Text web part มาวางแล้วสี ขนาด ไฮไลต์ และ "ไม่มีระยะห่าง" ไม่หาย (แปลงคลาสของ SharePoint เช่น fontColorRed, fontSizeXLarge เป็นรูปแบบจริง)
- แถบเครื่องมือขึ้นพร้อมแถบของ SharePoint ทุกครั้งที่เลือก web part และอยู่เหนือกรอบเสมอ ไม่เข้าไปอยู่ในช่องพิมพ์
- ความปลอดภัย: ตัวกรอง HTML เก็บ CSS เฉพาะที่ตัวแก้ไขใช้ และรับรูปเฉพาะที่อยู่ http/https หรือ `/` (ไม่รับ `data:`)
- คง Solution ID, Feature ID และ Web Part ID เดิม อัปโหลดทับรุ่น 1.1.1.0 หรือ 1.2.0.0 ได้ (Replace) และข้อความเดิมในหน้าเพจยังใช้ได้

## 1.1.1.0 — 21 ตุลาคม 2026

**ปรับปรุงไอคอนและรายละเอียดแพ็กเกจ**

- เพิ่มไอคอนเฉพาะของแอปสำหรับแสดงใน SharePoint App Catalog
- เปลี่ยนไอคอนของ Web Part จากสัญลักษณ์มาตรฐานเป็นภาพไอคอนเฉพาะ
- อัปเดตเวอร์ชัน Solution และ Feature จาก `1.1.0.0` เป็น `1.1.1.0`
- คงการทำงานของ Rich Text Editor และตัวเลือก **เปิดด้วย Chrome** เหมือนรุ่น 1.1.0.0
- คง Solution ID, Feature ID และ Web Part ID เดิมของรุ่น 1.1.0.0 เพื่อรองรับการอัปเดตแพ็กเกจเดิม

**Commit:** [Upgrade Nasarut-inchrome to 1.1.1.0 with custom icons](https://github.com/Anantayot/OpenInChrome-SPFx/commit/fe5b83eca50c8874b5eb831466ea86634d265f92)

## 1.1.0.0 — 21 ตุลาคม 2026

**ปรับปรุงครั้งใหญ่: จากลิงก์เดี่ยวเป็น Web Part สำหรับแก้ไขข้อความ**

- เปลี่ยนจาก Web Part ที่กำหนดข้อความและ URL ของลิงก์เดียว มาเป็นตัวแก้ไขข้อความบนหน้า SharePoint คล้าย Text Web Part
- เพิ่มแถบเครื่องมือจัดรูปแบบข้อความ รวมถึงการตั้งค่าลิงก์ภายในเนื้อหา
- เพิ่มตัวเลือก **เปิดด้วย Chrome** ในหน้าต่างใส่ลิงก์ เพื่อเลือกเปิด Chrome เฉพาะลิงก์ที่ต้องการ
- เมื่อเลือกเปิดด้วย Chrome ระบบจะเติม `nasarut-inchrome-chrome:` ให้กับ URL แบบ `http://` หรือ `https://` อัตโนมัติ
- เพิ่มการตรวจสอบ URL และกรอง HTML ด้วย DOMPurify ก่อนบันทึกหรือแสดงผล
- จัดโครงสร้างโครงการเป็น `nasarut-inchrome/` และใช้ GitHub Actions (Node.js 22 / SPFx 1.22.2) เพื่อ Build ไฟล์ `.sppkg`
- กำหนดชื่อแพ็กเกจและ Web Part ให้เป็น **Nasarut-inchrome**

**หมายเหตุสำคัญ:** รุ่น 1.1.0.0 ใช้ Web Part ID ใหม่ต่างจากรุ่น 1.0.2.0 แม้จะใช้ Solution ID เดียวกัน จึงควรตรวจสอบหน้า SharePoint เดิมเมื่ออัปเกรด และอาจต้องเพิ่ม Web Part รุ่นใหม่ลงหน้าเพจอีกครั้ง

**Commit:** [Unify project as Nasarut-inchrome 1.1.0.0](https://github.com/Anantayot/OpenInChrome-SPFx/commit/162c0a1b475c9a213343f5493e9698ee3a317182)

## 1.0.2.0 — 20 ตุลาคม 2026

**เปลี่ยนชื่อแอปให้เป็น Nasarut-inchrome**

- เปลี่ยนชื่อ Solution และชื่อ Web Part ที่แสดงใน SharePoint เป็น **Nasarut-inchrome**
- ปรับชื่อไฟล์แพ็กเกจและชื่อ Artifact ในขั้นตอน GitHub Actions ให้สอดคล้องกัน
- เปลี่ยนข้อความอธิบายในหน้าตั้งค่าจาก `Open in Chrome` เป็น `Nasarut-inchrome`
- เพิ่มเวอร์ชันเป็น `1.0.2.0` โดยยังคงแนวทาง Web Part สำหรับลิงก์เดียว

**Commit:** [Rename SPFx application to Nasarut-inchrome and bump version to 1.0.2.0](https://github.com/Anantayot/OpenInChrome-SPFx/commit/3f88a809116e01a911c7e68572e939c2035860dc)

## 1.0.1.0 — 20 ตุลาคม 2026

**แก้ไขการคลิกลิงก์ผ่าน SharePoint**

- เพิ่ม `data-interception="off"` ให้ลิงก์ เพื่อไม่ให้ระบบนำทางของ SharePoint ดักการคลิกที่ควรส่งต่อไปยัง Windows custom protocol
- ปรับขั้นตอน Build ให้คง Solution ID, Feature ID และ Web Part ID เพื่อหลีกเลี่ยงการสร้างตัวตนใหม่ทุกครั้งที่ Build
- เพิ่มเวอร์ชัน Solution เป็น `1.0.1.0`

**Commit:** [Disable SharePoint link interception and preserve IDs for v1.0.1.0 upgrade](https://github.com/Anantayot/OpenInChrome-SPFx/commit/fedebe5ba54f80df26085434bdc21c424541af99)

## 1.0.0.0 — 20 ตุลาคม 2026 (รุ่นเริ่มต้น)

**เริ่มสร้าง Web Part สำหรับเปิดลิงก์ใน Chrome**

- พัฒนา SPFx Web Part สำหรับ SharePoint Online เพื่อแสดงลิงก์ที่ผู้ใช้คลิกได้
- เพิ่มช่องตั้งค่า **Text to display** และ **Address** เพื่อกำหนดชื่อและ URL ของลิงก์โดยไม่ต้องแก้โค้ด
- รองรับลิงก์ที่ใช้โปรโตคอล `nasarut-inchrome-chrome:` นำหน้า `http://` หรือ `https://`
- เริ่มใช้ GitHub Actions และ Node.js 22 ในการสร้างแพ็กเกจสำหรับติดตั้งบน SharePoint

**Commit:** [Add configurable custom-protocol hyperlink SPFx source](https://github.com/Anantayot/OpenInChrome-SPFx/commit/585723a9efc72b3930bbd7967d7a218553d92c66)

---

## หมายเหตุสำหรับการใช้งานและอัปเกรด

- ไฟล์เวอร์ชันล่าสุดอยู่ที่ [`dist/Nasarut-inchrome.sppkg`](dist/Nasarut-inchrome.sppkg)
- เครื่องผู้ใช้งานต้องมีการลงทะเบียน Windows custom protocol `nasarut-inchrome-chrome:` โดยฝ่าย IT ก่อน จึงจะเรียกเปิด Chrome ได้
- บันทึกนี้อ้างอิงการเปลี่ยนแปลงใน Source Code และผล Build เท่านั้น การใช้งานจริงยังต้องทดสอบบนหน้า SharePoint ขององค์กร
